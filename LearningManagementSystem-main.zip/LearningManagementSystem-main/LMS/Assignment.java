package LMS;

/**
 * Generic class for all assignment objects. This includes multiple choice tests,
 * quizzes, homeworks, and short answer questions.
 */

public class Assignment {

}
