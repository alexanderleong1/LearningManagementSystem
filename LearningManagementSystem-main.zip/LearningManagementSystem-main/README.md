# Learning Management System
A learning management system used to manage courses, instructors, and students for an educational institution. Includes features to create, enroll, and search for user information. Makes it easy to manage numerous students in one software application.
