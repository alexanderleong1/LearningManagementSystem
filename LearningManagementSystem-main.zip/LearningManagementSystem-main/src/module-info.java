module PersonalProjects {
    requires javafx.graphics;
    requires javafx.controls;
    requires javafx.fxml;

    opens LMS;
}